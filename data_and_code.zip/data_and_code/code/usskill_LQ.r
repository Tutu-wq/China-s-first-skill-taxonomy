
#getwd()
###calculate rca###
RCA <- function (mat, binary = FALSE) {
  mat <- as.matrix(mat)
  share_tech_city  <- mat/rowSums(mat)
     <- colSums(mat)/sum(mat)
  LQ <- t(t(share_tech_city)/share_tech_total)
  LQ[is.na(LQ)] <- 0
  if (binary) {
    LQ[LQ < 1] <- 0
    LQ[LQ > 1] <- 1
  }
  return(LQ)
}
df=read.csv("us_161skill_696occupation_v2018_vnj.csv",row.names = 1)
df=df[,-c(1:3)]  ###delete the description
LQ=RCA(mat = df,binary = TRUE)
write.csv(LQ,"usskill_LQ.csv")
