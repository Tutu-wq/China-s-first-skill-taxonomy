
co.occurrence <- function(mat, diagonal = FALSE, list = FALSE) {
  
  library (Matrix)
  
  mat = as.matrix (mat)
  
  cooc = Matrix::t(mat)%*% mat 
  cooc = as.matrix (cooc)
  
  if (!diagonal) {
    diag(cooc) <- 0
  }
  
  return (cooc)
  
}  ### calculate the co-occurrence frequency
proximity=function(co){
  cols=colSums(LQ)
  pro=sweep(co,1,cols,"/")
  tf= pro<t(pro)
  minprob=pro*tf+t(pro)*(!tf)
}  ### calculate the minimun probability of co-occurrence 

LQ=read.csv("cnskill_LQ.csv",row.names = 1,stringsAsFactors = F)
LQ=LQ[,-c(1:4)]  ###delete the description
co=co.occurrence(mat=LQ)
prox=proximity(co=co)
hist(prox,breaks = 100)
write.csv(prox,"cn_skill_proximity.csv")


