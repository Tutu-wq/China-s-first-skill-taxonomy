# -*- coding: utf-8 -*-
"""
Created on Mon Nov 19 17:15:58 2018

@author: Weipan Xu
"""


import gensim
from gensim import corpora
from gensim.parsing.preprocessing import STOPWORDS
from gensim.utils import lemmatize
from gensim.models import VocabTransform
import logging
logging.basicConfig(format='%(levelname)s : %(message)s', level=logging.INFO)
logging.root.level = logging.INFO  # ipython sometimes messes up the logging setup; restore
import os
import pandas as pd
import copy
import re



os.chdir(".")
"""sequence1. US Occupation.  only keep the noun, verb and adjective """
df=pd.read_csv("us_161skill_696occupation_v2018_vnj.csv",encoding="gbk")
doc_complete=list(df['jobtext'])   ###读取列为des_cn
doc_clean = [lemmatize(text, min_length=3, stopwords=STOPWORDS,allowed_tags=re.compile('(VB|NN|JJ)')) for text in doc_complete]  
doc_clean2=[[string[:-3] for string in list ]for list in doc_clean] 
des_list=[] 
for i in range(len(doc_clean2)):
   words=""
   text=doc_clean2[i]
   for j in range(len(text)):
       word=text[j].decode("utf-8")
       words=words+"   "+word
   des_list.append(words)
df["jobtext_vnj"]=des_list
df.to_csv("us_161skill_696occupation_v2018_vnj.csv",index=False)


"""sequence1. US Occupation.  get the corpus of occupation """
dictionary= corpora.Dictionary(doc_clean2) 
corpus=[dictionary.doc2bow(doc) for doc in doc_clean2]
filtered_dictionary = copy.deepcopy(dictionary)
filtered_dictionary.filter_extremes(no_below=3, no_above=0.9,keep_tokens=None)
old2new = {dictionary.token2id[token]: new_id for new_id, token in filtered_dictionary.iteritems()}
vt = VocabTransform(old2new)
gensim.corpora.MmCorpus.serialize('filtered_corpus.mm', vt[corpus],id2word=filtered_dictionary)
filter_corpus=gensim.corpora.MmCorpus('filtered_corpus.mm')
###to form dense matrix
from scipy.sparse import lil_matrix
mat= lil_matrix((len(filter_corpus),len(filtered_dictionary)))
for i in range(len(filter_corpus)):
    doc=filter_corpus[i]
    for word in doc:
        j=word[0]
        mat[i,j]=word[1]
        print(i,word)
mat2=mat.toarray()
#mat2=mat2>0
mat2=mat2.astype("int")
skilltopic=pd.DataFrame(mat2,index=df["code"],columns=filtered_dictionary.values())
skilltopic.to_csv("us_corpus_vnj_3_90.csv")
        





"""sequence2. China Occupation.  only keep the noun, verb and adjective """

df=pd.read_csv("cn_occupation_dig3_vnj.csv",encoding="gbk")
doc_complete=list(df['jobtext_eng'])   
doc_clean = [lemmatize(text, min_length=3, stopwords=STOPWORDS,allowed_tags=re.compile('(VB|NN|JJ)')) for text in doc_complete]  
doc_clean2=[[string[:-3] for string in list ]for list in doc_clean] 
des_list=[] 
for i in range(len(doc_clean2)):
   words=""
   text=doc_clean2[i]
   for j in range(len(text)):
       word=text[j].decode("utf-8")
       words=words+"   "+word
   des_list.append(words)
df["jobtext_vnj"]=des_list
df.to_csv("cn_occupation_dig3_vnj.csv",index=False)









