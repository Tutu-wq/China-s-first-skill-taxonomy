# -*- coding: utf-8 -*-
"""
Created on Sat Dec  8 10:35:03 2018

@author: Weipan Xu
"""

####mutual information###

import pandas as pd
from sklearn import metrics as mr
from scipy.sparse import lil_matrix
import os
os.getcwd()
os.chdir(".")

df=pd.read_csv("usskill_LQ.csv",encoding="gbk",index_col=0)

skills=list(df.columns)
task=pd.read_csv("us_corpus_vnj_3_90.csv",encoding="gbk",index_col=0)
task_skills=pd.DataFrame(skills)

mat= lil_matrix((len(task.columns),len(skills)))
for i in range(len(skills)):
    skill=skills[i]
    newstarget=df[skill]
    for j in range(len(task.columns)):
        keyword=task.columns[j]
        tasklabel=task[keyword]>0
        tasklabel=tasklabel.astype("int")
        mi=mr.mutual_info_score(newstarget,tasklabel)
        mat[j,i]=mi
        print(skill,keyword,mi)
    mat2=mat.toarray()
skilltopic=pd.DataFrame(mat2,index=task.columns,columns=skills)
skilltopic.to_csv("us_MI_taskskill_vnj.csv")
