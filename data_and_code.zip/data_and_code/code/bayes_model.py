# -*- coding: utf-8 -*-
"""
Created on Fri Dec  7 20:39:48 2018

@author: Weipan Xu
"""

from sklearn.cross_validation import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import BernoulliNB
from sklearn.metrics import classification_report
import pandas as pd
import csv
import os
os.chdir(".")

skillscores=pd.read_csv("cn_occupation_dig3_vnj.csv",encoding="gbk")   ###China's occupation text
cnjobtext=skillscores["jobtext_vnj"]  ###China's occupation text
usjobtext=pd.read_csv("us_161skill_696occupation_v2018_vnj.csv",encoding="gbk")    ####  train text
newsdata=usjobtext["jobtext_vnj"]   ####  us occupaton feature
label=pd.read_csv("usskill_LQ.csv",index_col=0)  ####  us skill label
cnskills=skillscores    ####  for append 
skills=label.columns     #### get the uniqut

wf=open(r"accuracy.csv","w") ###Calculate the accuracy###
writer=csv.writer(wf)
writer.writerow(["skill","trainscore","testscore","important_num"])
   

for skill in skills:
    newstarget=label[skill]
    X_train,X_test,y_train,y_test=train_test_split(newsdata,newstarget,test_size=0.1,random_state=33)
    vec=CountVectorizer()
    X_train=vec.fit_transform(X_train)
    vectorizer_test = CountVectorizer(vocabulary=vec.vocabulary_)
    X_test = vectorizer_test.transform(X_test)
    #-------------training
    #initialize NB model with default config
    mnb=BernoulliNB(alpha=1,binarize=0.0, class_prior=None, fit_prior=True)
    #training model
    #mnb=MultinomialNB(alpha=0)
    mnb.fit(X_train,y_train)
    #run on test data
    y_predict=mnb.predict(X_test)
    #-------------performance
    testscore=mnb.score(X_test,y_test)
    trainscore=mnb.score(X_train,y_train)
    imp=sum(newstarget)

    writer.writerow([skill,trainscore,testscore,imp])
    print ('The test Accuracy is',mnb.score(X_test,y_test),skill)
    print ('The train Accuracy is',mnb.score(X_train,y_train),skill)
    print (classification_report(y_test,y_predict))

    presample = vectorizer_test.transform(cnjobtext)
    new_predict=mnb.predict(presample)
    new_predict=new_predict.astype('int')
    cnskills[skill]=new_predict
    
wf.close()

cnskills.to_csv("cnskill_LQ.csv",index=0)
